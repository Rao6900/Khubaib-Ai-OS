---
name: Gemini model availability
description: The Gemini API may retire older Flash model names for new users even when the SDK still accepts them.
---

Gemini model names can change independently of the JavaScript SDK. A model that was previously valid may return a 404 for new users; use a currently listed Flash model and verify with a small non-sensitive smoke call before declaring the bot ready.

**Why:** The first runtime smoke check exposed that `gemini-2.5-flash` was no longer available to new users, while the stored key itself was valid.

**How to apply:** Treat a model-specific 404 as a model selection issue, not a credential failure. Update the configured model, rebuild, restart, and retry without printing secrets or response content.