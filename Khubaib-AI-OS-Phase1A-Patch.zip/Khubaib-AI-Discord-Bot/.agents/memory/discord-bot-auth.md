---
name: Discord bot authentication
description: Discord OAuth connections are not enough for server message automation; bots need their own bot token and privileged intent configuration.
---

Discord user OAuth access can cover identity and server listing, but reading or posting server messages requires a separate Discord application bot token. Message-content access also requires enabling the privileged Message Content Intent in the Discord Developer Portal.

**Why:** Discord enforces a token-type boundary and rejects gateway sessions that request privileged intents without the corresponding developer-portal toggle.

**How to apply:** For future Discord bot work, keep the bot token in Replit Secrets, never log it, and make the Message Content Intent setup an explicit launch prerequisite.