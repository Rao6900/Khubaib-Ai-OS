# Khubaib AI

Khubaib AI is a Discord AI CEO and Chief of Staff with a routed Strategy Agent for business planning and analysis.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string
- Required secrets: `DISCORD_BOT_TOKEN`, `GEMINI_API_KEY`
- Optional routed-provider secrets: `GROQ_API_KEY`, `OPENROUTER_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/src/bot/index.ts` — Discord gateway, slash commands, message handling, and in-memory conversation context
- `artifacts/api-server/src/bot/ai.ts` — Gemini response generation
- `artifacts/api-server/src/bot/model-router.ts` — Gemini/Groq/OpenRouter routing and fallback order
- `artifacts/api-server/src/bot/strategy/agent.ts` — Strategy Agent prompt, policy boundary, report format, and analysis orchestration
- `artifacts/api-server/src/index.ts` — starts the API server and Discord bot together

## Architecture decisions

- Discord uses a bot token secret because a Discord OAuth connection cannot read or send server messages.
- Gemini calls use the current low-cost `gemini-3-flash-preview` model through the user's own key.
- Normal requests route Gemini → Groq → OpenRouter; fast analysis routes Groq → Gemini → OpenRouter; complex analysis routes OpenRouter → Gemini → Groq.
- The Strategy Agent reuses the existing channel-scoped in-memory history and does not create a second memory system.
- Khubaib AI responds to mentions, DMs, `/ask`, and `/help` to avoid unsolicited server-wide spam.
- Mentions in a channel named `#strategy` and the `/strategy` command use the Strategy Agent without changing Discord roles, channels, or permissions.
- Conversation history is intentionally in-memory and scoped per channel for a simple first version.

## Product

- Responds to `@Khubaib AI` mentions in server channels
- Replies to direct messages
- Supports `/ask` and `/help`
- Keeps a short rolling context per channel while the process is running

## User preferences

- Keep the bot simple and free to operate where possible.
- Never expose or print Discord credentials.

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
