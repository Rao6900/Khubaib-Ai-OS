# Khubaib AI

Khubaib AI is a small Discord AI bot backed by Gemini.

## What it does

- Replies when mentioned in a server channel
- Replies to direct messages
- Provides `/ask` and `/help` slash commands
- Provides `/strategy` with normal, fast, and complex routing modes
- Routes normal, fast, and complex requests across Gemini, Groq, and OpenRouter with fallback
- Keeps a short, in-memory conversation context per channel

## Setup

Create a Discord application with a bot user, enable **Message Content Intent**, and invite it with the `bot` and `applications.commands` scopes. The bot needs permission to view channels, read message history, send messages, and use slash commands.

The app expects these project secrets:

- `DISCORD_BOT_TOKEN`
- `GEMINI_API_KEY`
- `GROQ_API_KEY` (optional fallback)
- `OPENROUTER_API_KEY` (optional fallback)

Start it with:

```sh
pnpm --filter @workspace/api-server run dev
```

The API health check is available at `/api/healthz`. Bot logs never include either secret.