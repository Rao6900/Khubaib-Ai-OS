import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  agentEvents,
  approvals,
  businesses,
  memoryEntries,
  tasks,
} from "@workspace/db/schema";

export type MemoryKind = "FACT" | "DECISION" | "TASK" | "OBSERVATION" | "RECOMMENDATION" | "MESSAGE";

export async function getChannelHistory(channelId: string, limit = 12) {
  const rows = await db
    .select()
    .from(memoryEntries)
    .where(and(eq(memoryEntries.category, "CONVERSATION"), eq(memoryEntries.subject, channelId)))
    .orderBy(desc(memoryEntries.createdAt))
    .limit(limit);

  return rows.reverse();
}

export async function appendChannelTurn(
  channelId: string,
  role: "user" | "model",
  text: string,
  createdBy: string,
) {
  await db.insert(memoryEntries).values({
    category: "CONVERSATION",
    kind: "MESSAGE",
    subject: channelId,
    content: JSON.stringify({ role, text }),
    source: "discord",
    verified: true,
    createdBy,
  });
}

export async function createMemory(input: {
  category: string;
  kind: MemoryKind;
  subject: string;
  content: string;
  source?: string;
  verified?: boolean;
  createdBy: string;
}) {
  const [row] = await db.insert(memoryEntries).values({
    ...input,
    source: input.source ?? "system",
    verified: input.verified ?? false,
  }).returning();
  return row;
}

export async function createTask(input: {
  taskId: string;
  title: string;
  description: string;
  createdBy: string;
  assignedAgent: string;
  priority?: string;
  dueAt?: Date;
  dependencies?: string[];
  riskLevel?: string;
  approvalRequired?: boolean;
}) {
  const [row] = await db.insert(tasks).values({
    ...input,
    priority: input.priority ?? "Medium",
    dependencies: input.dependencies ?? [],
    riskLevel: input.riskLevel ?? "GREEN",
    approvalRequired: input.approvalRequired ?? false,
  }).returning();
  return row;
}

export async function updateTask(taskId: string, patch: Partial<{
  status: string;
  priority: string;
  assignedAgent: string;
  dueAt: Date | null;
  result: string | null;
  notes: string | null;
}>) {
  const [row] = await db.update(tasks)
    .set({
      ...patch,
      completionAt: patch.status === "COMPLETED" ? new Date() : undefined,
    })
    .where(eq(tasks.taskId, taskId))
    .returning();
  return row;
}

export async function listActiveTasks(limit = 25) {
  return db.select().from(tasks)
    .where(inArray(tasks.status, ["BACKLOG", "PLANNED", "IN_PROGRESS", "BLOCKED", "AWAITING_APPROVAL"]))
    .orderBy(desc(tasks.createdAt))
    .limit(limit);
}

export async function createApproval(input: {
  approvalId: string;
  action: string;
  reason: string;
  expectedBenefit: string;
  cost: string;
  risk: string;
  reversibility: string;
  recommendedDecision: string;
  requestedBy: string;
}) {
  const [row] = await db.insert(approvals).values(input).returning();
  return row;
}

export async function decideApproval(approvalId: string, status: "APPROVED" | "REJECTED", decisionNotes?: string) {
  const [row] = await db.update(approvals)
    .set({ status, decidedAt: new Date(), decisionNotes: decisionNotes ?? null })
    .where(eq(approvals.approvalId, approvalId))
    .returning();
  return row;
}

export async function listPendingApprovals(limit = 25) {
  return db.select().from(approvals)
    .where(eq(approvals.status, "PENDING"))
    .orderBy(desc(approvals.createdAt))
    .limit(limit);
}

export async function recordAgentEvent(input: {
  agent: string;
  eventType: string;
  taskId?: string;
  status: string;
  payload?: Record<string, unknown>;
}) {
  const [row] = await db.insert(agentEvents).values({
    ...input,
    payload: input.payload ?? {},
  }).returning();
  return row;
}

export async function ensureBusinessPortfolio() {
  const defaults = [
    ["personal-brand", "Dr. Khubaib Tariq — Personal Brand"],
    ["health-clinic", "Tariq Jameel Health Clinic"],
    ["derma-fix", "Derma Fix Cosmetics"],
    ["future-businesses", "Future Businesses"],
  ] as const;

  for (const [slug, name] of defaults) {
    const existing = await db.select({ id: businesses.id }).from(businesses).where(eq(businesses.slug, slug)).limit(1);
    if (existing.length === 0) {
      await db.insert(businesses).values({ slug, name, description: null });
    }
  }
}

export function decodeConversationContent(content: string): { role: "user" | "model"; text: string } | null {
  try {
    const value = JSON.parse(content) as { role?: string; text?: string };
    if ((value.role === "user" || value.role === "model") && typeof value.text === "string") {
      return { role: value.role, text: value.text };
    }
  } catch {
    // Ignore malformed legacy entries.
  }
  return null;
}
