import {
  Client,
  Events,
  GatewayIntentBits,
  Partials,
  SlashCommandBuilder,
  type Message,
} from "discord.js";
import { logger } from "../lib/logger";
import { generateKhubaibReply, type ChatTurn } from "./ai";
import {
  getModelRoutingStatus,
  type ChatMessage,
  type RoutingMode,
} from "./model-router";
import { runStrategyAgent } from "./strategy/agent";
import {
  appendChannelTurn,
  decodeConversationContent,
  ensureBusinessPortfolio,
  getChannelHistory,
  recordAgentEvent,
} from "./os-store";

const maxHistoryTurns = 12;
const channelQueues = new Map<string, Promise<void>>();

const commands = [
  new SlashCommandBuilder()
    .setName("ask")
    .setDescription("Ask Khubaib AI a question")
    .addStringOption((option) =>
      option
        .setName("question")
        .setDescription("What would you like to know?")
        .setRequired(true),
    ),
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("See how to use Khubaib AI"),
  new SlashCommandBuilder()
    .setName("strategy")
    .setDescription("Ask the Strategy Agent for a structured recommendation")
    .addStringOption((option) =>
      option
        .setName("objective")
        .setDescription("The business objective or strategy question")
        .setRequired(true),
    )
    .addStringOption((option) =>
      option
        .setName("business")
        .setDescription("The business this relates to")
        .addChoices(
          { name: "Personal Brand", value: "Dr. Khubaib Tariq Personal Brand" },
          { name: "Health Clinic", value: "Tariq Jameel Health Clinic" },
          { name: "Derma Fix Cosmetics", value: "Derma Fix Cosmetics" },
          { name: "Future Opportunity", value: "Future business opportunity" },
          { name: "Portfolio-wide", value: "Portfolio-wide" },
        ),
    )
    .addStringOption((option) =>
      option
        .setName("mode")
        .setDescription("How deeply to route the analysis")
        .addChoices(
          { name: "Normal planning", value: "normal" },
          { name: "Fast analysis", value: "fast" },
          { name: "Complex reasoning", value: "complex" },
        ),
    ),
].map((command) => command.toJSON());

function splitReply(reply: string) {
  const chunks: string[] = [];
  let remaining = reply;

  while (remaining.length > 2000) {
    let splitAt = remaining.lastIndexOf("\n", 2000);
    if (splitAt < 800) splitAt = remaining.lastIndexOf(" ", 2000);
    if (splitAt < 800) splitAt = 2000;
    chunks.push(remaining.slice(0, splitAt).trim());
    remaining = remaining.slice(splitAt).trimStart();
  }

  if (remaining) chunks.push(remaining);
  return chunks;
}

function toStrategyHistory(history: ChatTurn[]): ChatMessage[] {
  return history.map((turn) => ({
    role: turn.role === "model" ? "assistant" : "user",
    content: turn.parts[0].text,
  }));
}

function channelName(channel: Message["channel"]) {
  return "name" in channel && typeof channel.name === "string"
    ? channel.name.toLowerCase()
    : undefined;
}

async function loadHistory(channelId: string): Promise<ChatTurn[]> {
  try {
    const rows = await getChannelHistory(channelId, maxHistoryTurns);
    return rows
      .map((row) => decodeConversationContent(row.content))
      .filter((turn): turn is { role: "user" | "model"; text: string } => turn !== null)
      .map((turn) => ({ role: turn.role, parts: [{ text: turn.text }] }));
  } catch (error) {
    logger.error({ error: error instanceof Error ? error.message : String(error), channelId }, "Persistent history load failed");
    return [];
  }
}

async function replyWithAi(
  message: Message,
  prompt: string,
  strategyMode = false,
) {
  const channelId = message.channelId;
  if (!message.channel.isSendable()) {
    throw new Error("This Discord channel cannot receive messages.");
  }
  const channel = message.channel;
  const previous = channelQueues.get(channelId) ?? Promise.resolve();

  const task = previous
    .catch(() => undefined)
    .then(async () => {
      await channel.sendTyping();

      const history = await loadHistory(channelId);
      const reply = strategyMode
        ? (
            await runStrategyAgent({
              objective: prompt,
              history: toStrategyHistory(history),
            })
          ).text
        : await generateKhubaibReply(history, message.author.displayName, prompt);

      await appendChannelTurn(channelId, "user", `${message.author.displayName}: ${prompt}`, message.author.id);
      await appendChannelTurn(channelId, "model", reply, "Khubaib AI");
      await recordAgentEvent({
        agent: "AI CEO",
        eventType: "CONVERSATION_COMPLETED",
        status: "COMPLETED",
        payload: { channelId, strategyMode, provider: "routed" },
      });

      const chunks = splitReply(reply);
      const [first, ...rest] = chunks;
      if (first) {
        await message.reply({
          content: first,
          allowedMentions: { repliedUser: false },
        });
      }
      for (const chunk of rest) {
        await channel.send(chunk);
      }
    });

  const trackedTask = task.finally(() => {
    if (channelQueues.get(channelId) === trackedTask) {
      channelQueues.delete(channelId);
    }
  });
  channelQueues.set(channelId, trackedTask);

  await trackedTask;
}

function cleanMention(content: string) {
  return content.replace(/<@!?\d+>/g, "").trim();
}

export async function startDiscordBot() {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) {
    throw new Error("DISCORD_BOT_TOKEN is not configured.");
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.DirectMessages,
      GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.Channel],
  });

  client.once(Events.ClientReady, async (readyClient) => {
    await readyClient.application.commands.set(commands);
    try {
      await ensureBusinessPortfolio();
      logger.info("AI OS business portfolio initialized");
    } catch (error) {
      logger.error({ error: error instanceof Error ? error.message : String(error) }, "AI OS business portfolio initialization failed");
    }
    logger.info({ providers: getModelRoutingStatus() }, "AI model router ready");
    logger.info(
      { username: readyClient.user.username, guilds: readyClient.guilds.cache.size },
      "Khubaib AI is online",
    );
  });

  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    if (interaction.commandName === "help") {
      await interaction.reply({
        content:
          "I’m Khubaib AI. Mention me in a server or send me a DM to chat. You can also use `/ask question:<your question>`.",
        ephemeral: true,
      });
      return;
    }

    if (interaction.commandName === "strategy") {
      const objective = interaction.options.getString("objective", true);
      const business = interaction.options.getString("business") ?? undefined;
      const mode = (interaction.options.getString("mode") ?? "normal") as RoutingMode;
      await interaction.deferReply();

      try {
        const history = await loadHistory(interaction.channelId);
        const result = await runStrategyAgent({
          objective,
          business,
          mode,
          history: toStrategyHistory(history),
        });
        await appendChannelTurn(interaction.channelId, "user", objective, interaction.user.id);
        await appendChannelTurn(interaction.channelId, "model", result.text, "Strategy Agent");
        await recordAgentEvent({
          agent: "Strategy Agent",
          eventType: "STRATEGY_COMPLETED",
          status: "COMPLETED",
          payload: { channelId: interaction.channelId, approvalRequired: result.approvalRequired, provider: result.provider },
        });

        const chunks = splitReply(result.text);
        await interaction.editReply(chunks[0] ?? result.text);
        for (const chunk of chunks.slice(1)) {
          await interaction.followUp(chunk);
        }
      } catch (error) {
        logger.error(
          { error: error instanceof Error ? error.message : String(error) },
          "Strategy Agent slash command failed",
        );
        await interaction.editReply(
          "The Strategy Agent could not complete this analysis right now. No action was taken.",
        );
      }
      return;
    }

    if (interaction.commandName === "ask") {
      const question = interaction.options.getString("question", true);
      await interaction.deferReply();

      try {
        const history = await loadHistory(interaction.channelId);
        const reply = await generateKhubaibReply(
          history,
          interaction.user.globalName ?? interaction.user.username,
          question,
        );
        await appendChannelTurn(interaction.channelId, "user", `${interaction.user.username}: ${question}`, interaction.user.id);
        await appendChannelTurn(interaction.channelId, "model", reply, "Khubaib AI");
        await interaction.editReply(splitReply(reply)[0] ?? reply);
      } catch (error) {
        logger.error(
          { error: error instanceof Error ? error.message : String(error) },
          "Khubaib AI slash command failed",
        );
        await interaction.editReply(
          "I couldn’t reach the AI model right now. Please try again in a moment.",
        );
      }
    }
  });

  client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;

    const isDirectMessage = message.channel.isDMBased();
    const isMentioned = client.user ? message.mentions.users.has(client.user.id) : false;
    if (!isDirectMessage && !isMentioned) return;
    const strategyMode = !isDirectMessage && channelName(message.channel) === "strategy";

    const prompt = cleanMention(message.content);
    if (!prompt) {
      await message.reply({
        content: "Hi. Ask me anything and I’ll do my best to help.",
        allowedMentions: { repliedUser: false },
      });
      return;
    }

    try {
      await replyWithAi(message, prompt, strategyMode);
    } catch (error) {
      logger.error(
        { error: error instanceof Error ? error.message : String(error) },
        "Khubaib AI message reply failed",
      );
      await message.reply({
        content: "I couldn’t reach the AI model right now. Please try again in a moment.",
        allowedMentions: { repliedUser: false },
      });
    }
  });

  client.on(Events.Error, (error) => {
    logger.error(
      { error: error instanceof Error ? error.message : String(error) },
      "Discord client error",
    );
  });

  await client.login(token);
  return client;
}