import {
  routeChat,
  type ChatMessage,
  type RouteResult,
  type RoutingMode,
} from "../model-router";

export type StrategyAgentRequest = {
  objective: string;
  business?: string;
  currentStatus?: string;
  mode?: RoutingMode;
  history?: ChatMessage[];
};

export type StrategyAgentResult = RouteResult & {
  approvalRequired: boolean;
};

const strategySystemInstruction = [
  "You are Strategy Agent inside KHUBAIB AI OS.",
  "You report to the AI CEO, who reports to the human CEO Dr. Khubaib Tariq.",
  "Your job is to convert CEO goals into actionable strategies, 30/60/90-day plans, objectives, tasks, KPIs, priorities, performance analysis, risks, and recommendations.",
  "Evaluate the Dr. Khubaib Tariq personal brand, Tariq Jameel Health Clinic, Derma Fix Cosmetics, and future business opportunities when relevant.",
  "You may analyze, plan, prioritize, recommend, create internal task recommendations, request information from other agents, review performance, and recommend strategy changes.",
  "You must not spend money, make financial, legal, or medical decisions, publish high-risk reputational content, delete important data, permanently change company strategy, or claim a recommendation was completed.",
  "You must not directly override another agent. Assign execution dependencies to Research, Operations, Marketing, Social Media, Finance, or Development agents for the AI CEO to coordinate.",
  "Use GREEN for autonomous low-risk analysis, YELLOW for analysis that should be reported, ORANGE when CEO approval is required before execution, and RED for CEO-only decisions.",
  "Be concise, structured, professional, candid about uncertainty, and never invent facts, permissions, completed work, capabilities, or data.",
  "Return this exact structure:",
  "AGENT: Strategy Agent",
  "OBJECTIVE: ...",
  "CURRENT STATUS: ...",
  "KEY FINDINGS: ...",
  "RECOMMENDATION: ...",
  "PRIORITY: Critical / High / Medium / Low",
  "ACTION PLAN: 1. ... 2. ... 3. ...",
  "KPI: ...",
  "RISKS: ...",
  "DEPENDENCIES: ...",
  "CEO APPROVAL REQUIRED: YES / NO",
].join("\n");

function requiresCeoApproval(text: string) {
  return [
    /\b(spend|invest|purchase|pay|allocate|commit funds|budget approval)\b/i,
    /\b(legal|contract|lawsuit|compliance|medical|diagnos|treatment)\b/i,
    /\b(publish|post|announce|reputation|public statement|press)\b/i,
    /\b(delete|remove permanently|irreversible|permanent change|rebrand)\b/i,
    /\b(hire|fire|terminate employment)\b/i,
  ].some((pattern) => pattern.test(text));
}

function enforceApprovalBoundary(text: string, approvalRequired: boolean) {
  const withoutApprovalLine = text
    .replace(/^CEO APPROVAL REQUIRED:\s*(YES|NO)\s*$/gim, "")
    .trim();
  return `${withoutApprovalLine}\n\nCEO APPROVAL REQUIRED: ${
    approvalRequired ? "YES" : "NO"
  }`;
}

function buildStrategyPrompt(request: StrategyAgentRequest) {
  const business = request.business?.trim() || "Portfolio-wide";
  const status = request.currentStatus?.trim() || "No current-status data supplied.";
  const approvalRequired = requiresCeoApproval(
    `${request.objective}\n${business}\n${status}`,
  );

  return {
    approvalRequired,
    prompt: [
      `Business or portfolio: ${business}`,
      `CEO objective: ${request.objective.trim()}`,
      `Current status: ${status}`,
      `Policy boundary: ${
        approvalRequired
          ? "This request touches a protected approval area. Recommend only; mark CEO APPROVAL REQUIRED: YES."
          : "This request is currently suitable for analysis and recommendation. Do not claim execution."
      }`,
      "Use the required standard output and distinguish known facts, assumptions, recommendations, and dependencies.",
    ].join("\n"),
  };
}

export async function runStrategyAgent(
  request: StrategyAgentRequest,
): Promise<StrategyAgentResult> {
  const { approvalRequired, prompt } = buildStrategyPrompt(request);
  const result = await routeChat({
    systemInstruction: strategySystemInstruction,
    messages: [
      ...(request.history ?? []).slice(-12),
      { role: "user", content: prompt },
    ],
    mode: request.mode ?? "normal",
  });

  return {
    ...result,
    approvalRequired,
    text: enforceApprovalBoundary(result.text, approvalRequired),
  };
}