import { GoogleGenerativeAI } from "@google/generative-ai";
import { logger } from "../lib/logger";

export type ModelProvider = "gemini" | "groq" | "openrouter";
export type RoutingMode = "normal" | "fast" | "complex";
export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

type ProviderRequest = {
  systemInstruction: string;
  messages: ChatMessage[];
};

export type RouteResult = {
  text: string;
  provider: ModelProvider;
  model: string;
  attemptedProviders: ModelProvider[];
};

export type ProviderCaller = (
  request: ProviderRequest,
) => Promise<string>;

const providerModels: Record<ModelProvider, string> = {
  gemini: "gemini-3-flash-preview",
  groq: "llama-3.1-8b-instant",
  openrouter: "meta-llama/llama-3.3-70b-instruct:free",
};

const providerOrder: Record<RoutingMode, ModelProvider[]> = {
  normal: ["gemini", "groq", "openrouter"],
  fast: ["groq", "gemini", "openrouter"],
  complex: ["openrouter", "gemini", "groq"],
};

function getProviderKey(provider: ModelProvider) {
  if (provider === "gemini") return process.env.GEMINI_API_KEY;
  if (provider === "groq") return process.env.GROQ_API_KEY;
  return process.env.OPENROUTER_API_KEY;
}

function getConfiguredProvider(provider: ModelProvider) {
  return Boolean(getProviderKey(provider));
}

function toGeminiContents(messages: ChatMessage[]) {
  return messages.map((message) => ({
    role: message.role === "assistant" ? "model" : "user",
    parts: [{ text: message.content }],
  }));
}

async function callGemini(request: ProviderRequest) {
  const apiKey = getProviderKey("gemini");
  if (!apiKey) throw new Error("GEMINI_API_KEY is not configured.");

  const model = new GoogleGenerativeAI(apiKey).getGenerativeModel({
    model: providerModels.gemini,
    systemInstruction: request.systemInstruction,
  });
  const result = await model.generateContent({
    contents: toGeminiContents(request.messages),
  });
  return result.response.text().trim();
}

async function callOpenAiCompatible(
  provider: "groq" | "openrouter",
  request: ProviderRequest,
) {
  const apiKey = getProviderKey(provider);
  if (!apiKey) {
    throw new Error(`${provider.toUpperCase()}_API_KEY is not configured.`);
  }

  const endpoint =
    provider === "groq"
      ? "https://api.groq.com/openai/v1/chat/completions"
      : "https://openrouter.ai/api/v1/chat/completions";
  const headers: Record<string, string> = {
    Authorization: `Bearer ${apiKey}`,
    "Content-Type": "application/json",
  };
  if (provider === "openrouter") {
    headers["HTTP-Referer"] = "https://replit.com";
    headers["X-Title"] = "Khubaib AI";
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers,
    body: JSON.stringify({
      model: providerModels[provider],
      messages: [
        { role: "system", content: request.systemInstruction },
        ...request.messages,
      ],
      max_tokens: 4096,
    }),
  });

  if (!response.ok) {
    throw new Error(`${provider} returned HTTP ${response.status}.`);
  }

  const payload = (await response.json()) as {
    choices?: Array<{ message?: { content?: string } }>;
  };
  const text = payload.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error(`${provider} returned an empty response.`);
  return text;
}

const callers: Record<ModelProvider, ProviderCaller> = {
  gemini: callGemini,
  groq: (request) => callOpenAiCompatible("groq", request),
  openrouter: (request) => callOpenAiCompatible("openrouter", request),
};

export function getModelRoutingStatus() {
  return (Object.keys(providerModels) as ModelProvider[]).map((provider) => ({
    provider,
    model: providerModels[provider],
    configured: getConfiguredProvider(provider),
  }));
}

export async function routeChat(
  request: ProviderRequest & { mode: RoutingMode },
  overrides: Partial<Record<ModelProvider, ProviderCaller>> = {},
): Promise<RouteResult> {
  const orderedProviders = providerOrder[request.mode];
  const attemptedProviders: ModelProvider[] = [];
  const failures: string[] = [];

  for (const provider of orderedProviders) {
    const caller = overrides[provider] ?? callers[provider];
    if (!overrides[provider] && !getConfiguredProvider(provider)) continue;

    attemptedProviders.push(provider);
    try {
      const text = await caller(request);
      if (!text.trim()) throw new Error("Provider returned an empty response.");
      return {
        text: text.trim(),
        provider,
        model: providerModels[provider],
        attemptedProviders,
      };
    } catch (error) {
      failures.push(provider);
      logger.warn(
        { provider, fallbackAvailable: attemptedProviders.length < orderedProviders.length },
        "AI provider failed; trying the next configured provider",
      );
    }
  }

  throw new Error(
    `No configured AI provider completed the request. Attempted: ${
      failures.join(", ") || "none"
    }.`,
  );
}