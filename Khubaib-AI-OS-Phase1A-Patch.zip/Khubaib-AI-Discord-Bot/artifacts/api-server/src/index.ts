import app from "./app";
import { startDiscordBot } from "./bot";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");
  void startDiscordBot().catch((error: unknown) => {
    const message = error instanceof Error ? error.message : String(error);
    const nextStep = message.includes("disallowed intents")
      ? "Enable Message Content Intent for the bot in the Discord Developer Portal, then restart the workflow."
      : undefined;
    logger.error(
      { error: message, nextStep },
      "Khubaib AI failed to start",
    );
  });
});
