import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";

export const memoryEntries = pgTable("memory_entries", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  kind: text("kind").notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  source: text("source").notNull().default("system"),
  verified: boolean("verified").notNull().default(false),
  createdBy: text("created_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const tasks = pgTable("os_tasks", {
  id: serial("id").primaryKey(),
  taskId: text("task_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  createdBy: text("created_by").notNull(),
  assignedAgent: text("assigned_agent").notNull(),
  priority: text("priority").notNull().default("Medium"),
  status: text("status").notNull().default("BACKLOG"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  dueAt: timestamp("due_at", { withTimezone: true }),
  dependencies: jsonb("dependencies").$type<string[]>().notNull().default([]),
  riskLevel: text("risk_level").notNull().default("GREEN"),
  approvalRequired: boolean("approval_required").notNull().default(false),
  completionAt: timestamp("completion_at", { withTimezone: true }),
  result: text("result"),
  notes: text("notes"),
});

export const approvals = pgTable("os_approvals", {
  id: serial("id").primaryKey(),
  approvalId: text("approval_id").notNull().unique(),
  action: text("action").notNull(),
  reason: text("reason").notNull(),
  expectedBenefit: text("expected_benefit").notNull(),
  cost: text("cost").notNull(),
  risk: text("risk").notNull(),
  reversibility: text("reversibility").notNull(),
  recommendedDecision: text("recommended_decision").notNull(),
  status: text("status").notNull().default("PENDING"),
  requestedBy: text("requested_by").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  decisionNotes: text("decision_notes"),
});

export const businesses = pgTable("os_businesses", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const agentEvents = pgTable("os_agent_events", {
  id: serial("id").primaryKey(),
  agent: text("agent").notNull(),
  eventType: text("event_type").notNull(),
  taskId: text("task_id"),
  status: text("status").notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const insertMemoryEntrySchema = createInsertSchema(memoryEntries);
export const insertTaskSchema = createInsertSchema(tasks);
export const insertApprovalSchema = createInsertSchema(approvals);
export const insertBusinessSchema = createInsertSchema(businesses);
export const insertAgentEventSchema = createInsertSchema(agentEvents);

export type MemoryEntry = typeof memoryEntries.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type Approval = typeof approvals.$inferSelect;
export type Business = typeof businesses.$inferSelect;
export type AgentEvent = typeof agentEvents.$inferSelect;